-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 29, 2022 at 04:09 PM
-- Server version: 8.0.30
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transplant`
--

-- --------------------------------------------------------

--
-- Table structure for table `organ`
--

DROP TABLE IF EXISTS `organ`;
CREATE TABLE IF NOT EXISTS `organ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organ_name` varchar(100) NOT NULL,
  `organ_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date_collected` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `organ`
--

INSERT INTO `organ` (`id`, `organ_name`, `organ_no`, `date_collected`) VALUES
(1, 'Heart', '5', '2022-09-30'),
(2, '', '', '2022-09-14'),
(3, 'Heart', '2', '2022-10-08'),
(4, 'Eye', '1', '2022-09-25'),
(5, 'Kidney', '1', '2022-09-29');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
CREATE TABLE IF NOT EXISTS `request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `comment` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date_reg` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `name`, `gender`, `dob`, `email`, `city`, `phone`, `comment`, `status`, `date_reg`) VALUES
(8, 'Ankit Maurya', 'M', '2001-11-30', 'ankit@gmail.com', 'Jaunpur', '7571884622', 'urgent need of heart transplant', 'Approved', '2022-09-24 10:26:33');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
