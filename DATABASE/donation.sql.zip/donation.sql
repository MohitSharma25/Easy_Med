-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 29, 2022 at 04:09 PM
-- Server version: 8.0.30
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donation`
--

-- --------------------------------------------------------

--
-- Table structure for table `announce`
--

DROP TABLE IF EXISTS `announce`;
CREATE TABLE IF NOT EXISTS `announce` (
  `id` int NOT NULL AUTO_INCREMENT,
  `announcement` varchar(50) NOT NULL,
  `bloodneed` varchar(3) NOT NULL,
  `dat` date NOT NULL,
  `organizer` varchar(50) NOT NULL,
  `requirements` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announce`
--

INSERT INTO `announce` (`id`, `announcement`, `bloodneed`, `dat`, `organizer`, `requirements`) VALUES
(1, 'DEMO ANNOUNCEMENT', 'A+', '2018-06-24', 'Vit Bhopal', 'Weight at least 50kg, No alcohol intake in 24hrs prior to donation, light meal should be taken before donation, be in good health, must be 18 years old and must have at least 3 month interval than the last donation.'),
(2, 'URGENT CASE: Serious Accident Condition', 'B-', '2021-03-26', 'City Hospital', 'Must be in good health and feeling very well. Must weigh at least 110 lbs.');

-- --------------------------------------------------------

--
-- Table structure for table `blood`
--

DROP TABLE IF EXISTS `blood`;
CREATE TABLE IF NOT EXISTS `blood` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `weight` int NOT NULL,
  `bloodgroup` varchar(3) NOT NULL,
  `address` varchar(20) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `bloodqty` int NOT NULL,
  `collection` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood`
--

INSERT INTO `blood` (`id`, `name`, `gender`, `dob`, `weight`, `bloodgroup`, `address`, `contact`, `bloodqty`, `collection`) VALUES
(9, 'Tom Filler', 'M', '1988-06-14', 69, 'AB+', 'Deo Adr', '7854447854', 312, '2020-12-30'),
(10, 'Elizabeth', 'F', '1990-02-12', 59, 'AB-', 'San Andrq', '8555554585', 310, '2020-12-30'),
(11, 'Shyaron', 'F', '1996-02-02', 60, 'B+', 'Demo Address', '7878787850', 360, '2020-12-29'),
(12, 'Harry Den', 'M', '1997-01-05', 70, 'B+', 'Demo', '8521112450', 310, '2020-12-29'),
(13, 'Tony Stank', 'M', '1980-03-03', 79, 'B+', 'CA', '8547778500', 312, '2020-12-27'),
(14, 'Stephen Strange', 'M', '1990-12-24', 69, 'O+', 'Demo', '8545554700', 310, '2020-12-27'),
(15, 'Steve Trevor', 'M', '1995-06-15', 75, 'O-', 'Demo Addresss', '7454447410', 311, '2021-01-05'),
(16, 'Martin', 'M', '1986-11-11', 85, 'AB+', 'demo', '8545557854', 310, '2021-01-05'),
(17, 'Russo', 'M', '1975-05-05', 80, 'O-', 'demooo', '7454447854', 360, '2021-01-02'),
(35, 'ankit', 'M', '2022-09-22', 62, 'B+', 'jaunpur', '7571884622', 2, '2022-09-30'),
(36, 'Sumit', 'F', '2022-09-06', 50, 'A+', 'sfa', '4356879808', 2, '2022-09-12'),
(40, 'Nidhi', 'F', '2003-07-21', 56, 'B+', 'jaunpur', '3243356324', 3, '2022-09-22'),
(41, 'Risav', 'M', '2003-01-03', 67, 'A+', 'bihar', '674675865', 2, '2022-09-22'),
(42, 'Ritesh', 'M', '2003-06-04', 89, 'B+', 'Pune', '9677543423', 1, '2022-09-22');

-- --------------------------------------------------------

--
-- Table structure for table `campaigndb`
--

DROP TABLE IF EXISTS `campaigndb`;
CREATE TABLE IF NOT EXISTS `campaigndb` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cname` varchar(50) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `phn` int NOT NULL,
  `cdate` date NOT NULL,
  `descp` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campaigndb`
--

INSERT INTO `campaigndb` (`id`, `cname`, `oname`, `phn`, `cdate`, `descp`) VALUES
(8, 'Saving Lives Together', 'Vit Bhopal', 1597534560, '2018-06-21', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

DROP TABLE IF EXISTS `donor`;
CREATE TABLE IF NOT EXISTS `donor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `guardiansname` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `weight` int NOT NULL,
  `bloodgroup` varchar(3) NOT NULL,
  `email` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `contact` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `name`, `guardiansname`, `gender`, `dob`, `weight`, `bloodgroup`, `email`, `address`, `contact`) VALUES
(18, 'Risav', 'Kanchan', 'M', '2020-09-03', 70, 'A+', 'demo@demo.com', 'demo', '8520002500'),
(19, 'Harry Den', 'Stephen Den', 'M', '1998-06-17', 70, 'B+', 'harry.den20@gmail.co', 'Demo Address', '7854445420'),
(20, 'Will Williams', 'Reth R Williams', 'M', '1996-07-16', 70, 'B+', 'williams@gmail.com', 'Demo Address', '0248887540'),
(21, 'John Doe', 'Kevin Doe', 'M', '1991-12-09', 69, 'AB+', 'doejohn@gmail.com', '905  Chandler Hollow', '7854445470'),
(22, 'Ramona Jr Pippin', 'Noramo Pippin', 'F', '1995-02-22', 55, 'O-', 'pippin@gmail.com', '3237  Drummond Stree', '7854445200'),
(23, 'Robert', 'Simon L Berg', 'M', '1994-06-21', 82, 'AB-', 'robert@gmail.com', '524  Duff Avenue', '2547778452'),
(24, 'Aman', 'Nisha', 'm', '2022-09-23', 56, 'A+', 'aman@gmail.com', 'jaunpur up', '9987462137'),
(29, 'Ankit maurya', 'Poonam ', 'M', '2001-11-30', 70, 'B+', 'ankit@gmail.com', 'jaunpur up', '7571884622'),
(30, 'Ritesh', 'Shinde sahab', 'M', '2003-01-06', 89, 'B+', 'ritesh@gmail.com', 'pune', '9867654345');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
